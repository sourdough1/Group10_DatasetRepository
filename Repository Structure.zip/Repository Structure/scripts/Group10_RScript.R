#load libraries
library(qgraph)
library(igraph)
library(bootnet)
library(matrixcalc)
library(networktools)

#Import data into environment
stress_data <- read.csv("Stress Dataset.csv")

#filter the relevant columns for analysis
selected_vars <- stress_data[, c( 
  "Have.you.recently.experienced.stress.in.your.life.",
  "Have.you.noticed.a.rapid.heartbeat.or.palpitations.",
  "Have.you.been.dealing.with.anxiety.or.tension.recently.",
  "Do.you.face.any.sleep.problems.or.difficulties.falling.asleep.",
  "Have.you.been.dealing.with.anxiety.or.tension.recently..1",
  "Have.you.been.getting.headaches.more.often.than.usual.",
  "Do.you.get.irritated.easily.",
  "Do.you.have.trouble.concentrating.on.your.academic.tasks.",
  "Have.you.been.feeling.sadness.or.low.mood.",
  "Have.you.been.experiencing.any.illness.or.health.issues.",
  "Do.you.often.feel.lonely.or.isolated.",
  "Do.you.feel.overwhelmed.with.your.academic.workload.",
  "Are.you.in.competition.with.your.peers..and.does.it.affect.you.",
  "Do.you.find.that.your.relationship.often.causes.you.stress.",
  "Are.you.facing.any.difficulties.with.your.professors.or.instructors.",
  "Is.your.working.environment.unpleasant.or.stressful.",
  "Do.you.struggle.to.find.time.for.relaxation.and.leisure.activities.",
  "Is.your.hostel.or.home.environment.causing.you.difficulties.",
  "Do.you.lack.confidence.in.your.academic.performance.",
  "Do.you.lack.confidence.in.your.choice.of.academic.subjects.",
  "Academic.and.extracurricular.activities.conflicting.for.you.",
  "Do.you.attend.classes.regularly.",
  "Have.you.gained.lost.weight."
)]

#rename columns for easier interpretation
colnames(selected_vars) <- c(
  "Recent Stress Experience",
  "Rapid Heartbeat",
  "Frequency of Anxiety",
  "Sleep disturbances",
  "Frequency of Anxiety (2)",
  "Frequency of headaches",
  "Increased irritability",
  "Difficulties concentrating on studies",
  "Experience of sadness",
  "Health issues ",
  "Feelings of loneliness",
  "Academic responsibilities overwhelmed",
  "Competition with peers stress",
  "Stress due to relationships",
  "Stress from difficulties with professors/instructors",
  "Unpleasant work environment",
  "Low relaxation time",
  "Stressful or difficult home",
  "lack of confidence in academic abilities",
  "Lack of confidence in academic subject choices",
  "Conflict between academic and extracurricular activities",
  "Frequency of class attendance",
  "Self-reported weight gain/loss as a stress indicator"
)
#Academic = 1, Lifestyle = 2, Social = 3
node_groups <- c(
  2, # Recent Stress Experience - lifestyle
  2, # Rapid heartbeat - lifestyle
  2, # Anxiety/tension - lifestyle
  2, # Sleep disturbances - lifestyle
  2, # Additional anxiety - lifestyle
  2, # Headaches - lifestyle
  3, # Irritability - social
  1, # Concentration - academic
  2, # Sadness - lifestyle
  2, # Health issues - lifestyle
  3, # Loneliness - social
  1, # Academic overwhelm - academic
  1, # Peer competition - academic
  3, # Relationships- social
  1, # Professors - academic
  3, # Work environment - social
  2, # No time for leisure - lifestyle
  3, # Home environment - social
  1, # Confidence in academics - academic
  1, # Confidence in subject choices - academic
  1, # Academics vs extracurriculars - academic
  1, # Class attendance - academic
  2  # Weight gain/loss - lifstyle
)

#Academic = Red, Lifestyle = Green, Social = Purple
group_colors <- c(
  "green",  # Recent Stress Experience
  "green",  # Rapid heartbeat
  "green",  # Anxiety/tension
  "green",  # Sleep disturbances
  "green",  # Additional anxiety
  "green",  # Headaches
  "purple", # Irritability
  "red",    # Concentration
  "green",  # Sadness
  "green",  # Health issues
  "purple", # Loneliness
  "red",    # Academic overwhelm
  "red",    # Peer competition
  "purple", # Stress from relationships
  "red",    # Professor-related stress
  "purple", # Stressful work environment
  "green",  # No time for leisure
  "purple", # Stressful home
  "red",    # Confidence in academics
  "red",    # Confidence in subject choices
  "red",    # Academic vs extracurricular
  "red",    # Class attendance
  "green"   # Weight gain/loss
)


#Normality Check
normality_results <- apply(selected_vars, 2, shapiro.test)
print(normality_results)

#Network estimation
network <- estimateNetwork(selected_vars, 
                           default = "ggmModSelect"
)

network_qgraph <-plot(network,
                      theme: "palette",
                      color = group_colors,
                      details = TRUE,
                      label.scale = FALSE,
                      label.cex = 0.5,        
                      vsize = 11,          
                      edge.width = 0.5,       
                      mar = c(3,3,3,3),
                      esize = 40,
                      height = 50,
                      width = 100
                      )
#save as pdf 
pdf("network5.pdf")

plot(network,
     theme: "palette",
     color = group_colors,
     details = TRUE,
     label.scale = FALSE,
     label.cex = 0.5,        
     vsize = 11,          
     edge.width = 0.5,       
     mar = c(3,3,3,3),
     esize = 40,
     height = 50,
     width = 100)
legend("topright",
       legend = c("Academic", "Lifestyle", "Social"),
       col = c("red", "green", "purple"),
       pch = 19, pt.cex = 1.5, bty = "n")
dev.off()

#measuring centrality
centralityPlot(network, 
               include = c("Degree", "Closeness", "Betweenness"))

network_centrality <- centrality(network)
network_centrality$Closeness
network_centrality$Betweenness

#weights matrix
network_weight <- getWmat(network)
ncol(network_weight) # No. of nodes
sum(network_weight[lower.tri(network_weight)]) # No. of edges
mean(network_weight[lower.tri(network_weight)])

#Bridge Centrality Analysis
bridge_results <- bridge(network = getWmat(network), communities = node_groups)
plot(bridge_results, include = "Bridge Strength", order = "value")
?bridge
?plot.bridge
# decreasing = TRUE to see the most important nodes first
sort(bridge_results$`Bridge Strength`, decreasing = TRUE)

#non-parametric bootstrap for edge weight stability
boot_nonparametric <- bootnet(network,
                              nBoots = 400,
                              nCores = 8,
                              statistics = c("edge", "strength", "closeness", "betweenness"))
#plot accuracy
plot(boot_nonparametric,
     order = "sample",
     labels = FALSE,
     plot = "interval",
     split0 = TRUE
     )

#plot differences
plot(boot_nonparametric,
     plot = "difference",
     onlyNonZero = TRUE,
     order = "sample")

#Case dropping bootstrap for centrality stability
boot_casedrop <- bootnet(network,
                         nBoots = 400,
                         nCores = 8,
                         type = "case",
                         statistics = c("strength", "betweenness", "closeness"))

plot(boot_casedrop,
     statistics = c("strength", "betweenness", "closeness"))

#CS-Coefficient (best if above 0.5):
corStability(boot_casedrop)
